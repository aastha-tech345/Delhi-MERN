module.exports = {
  secret: 'meditrinasecret', //key for jwt encryption
}