import { CCol, CRow } from '@coreui/react'
import React from 'react'

const Buttons = () => {
  return (
    <CRow>
      <CCol xs={12}>
        <h1>gdjgh</h1>
      </CCol>
    </CRow>
  )
}

export default Buttons
