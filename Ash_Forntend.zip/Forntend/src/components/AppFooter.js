import React from 'react'
import { CFooter } from '@coreui/react'

const AppFooter = () => {
  return <></>
}

export default React.memo(AppFooter)
